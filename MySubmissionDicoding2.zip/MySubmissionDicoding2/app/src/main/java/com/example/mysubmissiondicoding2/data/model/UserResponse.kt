package com.example.mysubmissiondicoding2.data.model

data class UserResponse(
	val items : ArrayList<User>
)
