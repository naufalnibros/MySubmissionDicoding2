package com.example.mysubmissiondicoding2.data.model

class User (
    val login:String,
    val id:Int,
    val avatar_url : String
    )